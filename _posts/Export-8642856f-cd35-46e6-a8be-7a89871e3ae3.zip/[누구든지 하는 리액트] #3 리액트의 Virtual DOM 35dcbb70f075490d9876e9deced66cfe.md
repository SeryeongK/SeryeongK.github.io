# [누구든지 하는 리액트] #3 리액트의 Virtual DOM

변화(Mutuation)이 일어나면 자바스크립트로 이루어진 가상의 DOM에 한 번 렌더링을 하고, 기존의 DOM과 비교를 한 다음에, 변화가 필요한 곳에만 업데이트

### React and the Virtual DOM

[https://youtu.be/muc2ZF0QIO4](https://youtu.be/muc2ZF0QIO4)

view: 전체 → React: 변화를 감지